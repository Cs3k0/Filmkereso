﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static Filmek.Class1;

namespace Filmkereso
{
    public partial class Window2 : Window
    {
        private ObservableCollection<Movie> movies = new ObservableCollection<Movie>();
        private readonly string filePath = "filmek.txt";

        public Window2()
        {
            InitializeComponent();
            MovieList.ItemsSource = movies;
            LoadMoviesFromFile();
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            if (int.TryParse(AirTimeBox.Text, out int airtime) &&
                int.TryParse(WatchedBox.Text, out int watched) &&
                int.TryParse(RateBox.Text, out int rate))
            {
                if (airtime < 1800 || airtime > 2025 || watched < 0 || rate < 0 || rate > 5 || string.IsNullOrWhiteSpace(NameBox.Text))
                {
                    MessageBox.Show("Rossz adatok....");
                }
                else
                {
                    var movie = new Movie(NameBox.Text, airtime, watched, rate);
                    movies.Add(movie);
                    SaveMovieToFile(movie); 

                    NameBox.Clear();
                    AirTimeBox.Clear();
                    WatchedBox.Clear();
                    RateBox.Clear();
                }
            }
            else
            {
                MessageBox.Show("Adj adatot");
            }
        }

        private void SaveMovieToFile(Movie movie)
        {
            try
            {
                string line = $"{movie.Name};{movie.AirTime};{movie.Watched};{movie.Rate}";
                File.AppendAllLines(filePath, new[] { line });
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Hiba a mentésénél: {ex.Message}");
            }
        }

        private void LoadMoviesFromFile()
        {
            if (!File.Exists(filePath))
                return;

            try
            {
                var lines = File.ReadAllLines(filePath);
                foreach (var line in lines)
                {
                    var parts = line.Split(';');
                    if (parts.Length == 4 &&
                        int.TryParse(parts[1], out int airtime) &&
                        int.TryParse(parts[2], out int watched) &&
                        int.TryParse(parts[3], out int rate))
                    {
                        var movie = new Movie(parts[0], airtime, watched, rate);
                        movies.Add(movie);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Hiba a beolvasáskor: {ex.Message}");
            }
        }
    }
}
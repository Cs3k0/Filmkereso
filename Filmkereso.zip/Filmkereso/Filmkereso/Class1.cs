﻿using System;

namespace Filmek
{
    internal class Class1
    {
        public class Movie
        {
            public string Name { get; set; }
            public int AirTime { get; set; }
            public int Watched { get; set; }
            public int Rate { get; set; }

            public Movie(string name, int airtime, int watched, int rate)
            {
                Name = name;
                AirTime = airtime;
                Watched = watched;
                Rate = rate;
            }

            public override string ToString()
            {
                return $"{Name} ({AirTime}) Watchers: {Watched} Rating: {Rate}/5";
            }
        }
    }
}

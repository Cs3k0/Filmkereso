﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static Filmek.Class1;

namespace Filmkereso
{
    public partial class Window3 : Window
    {
        private readonly string filePath = "filmek.txt";
        public Window3()
        {
            InitializeComponent();
            LoadSavedMovies();
        }
        private void LoadSavedMovies()
        {
            if (!File.Exists(filePath))
            {
                MessageBox.Show("Nincs file.....");
                return;
            }

            try
            {
                var lines = File.ReadAllLines(filePath);
                foreach (var line in lines)
                {
                    var parts = line.Split(';');
                    if (parts.Length == 4 &&
                        int.TryParse(parts[1], out int airtime) &&
                        int.TryParse(parts[2], out int watched) &&
                        int.TryParse(parts[3], out int rate))
                    {
                        var movie = new Movie(parts[0], airtime, watched, rate);
                        SavedMoviesList.Items.Add(movie.ToString());
                    }
                    else
                    {
                        SavedMoviesList.Items.Add("Hibás sor: " + line);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hiba a beolvasás közben: " + ex.Message);
            }
        }
    }
}
